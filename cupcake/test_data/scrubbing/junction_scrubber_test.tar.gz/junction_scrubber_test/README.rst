summarize_sample_GFF_junctions.py summarize.config test
scrub_sample_GFF_junctions.py scrub.config test.junction_detail.txt scrubbed --min_sample=2 --min_transcript=2
